#!/usr/bin/env bash

if [ -n $BROWSER = '' ]; then
  $BROWSER "$1"
elif which xdg-open > /dev/null; then
  xdg-open "$1"
elif which gnome-open > /dev/null; then
  gnome-open "$1"
else
  echo "Could not detect the web browser to use."
fi
