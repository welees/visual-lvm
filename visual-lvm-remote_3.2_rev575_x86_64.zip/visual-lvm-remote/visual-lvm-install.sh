#!/bin/bash
arch=`uname -i|grep x86_64`

if [[ $EUID -ne 0 ]]; then
	echo "Error: please run this command with root privilege!" 1>&2
	exit -2
fi

curpath=`pwd`
binpath=`dirname $0`
cd $binpath
this=`echo $0|sed "s/$binpath//"`
instpath=`pwd`
systemctl=`systemctl --version`|grep 'No command'	
case "$1" in
	remove)
		vlvmstart stop
		if [ -f /etc/visual_lvm/install.ini ]; then
			inst_path=`cat /etc/visual_lvm/install.ini|grep install_path|sed 's/install_path=//'`
			if [ "$systemctl" == "" ]; then
				vlvmstart stop
				systemctl stop visual-lvm.service
				systemctl disable visual-lvm.service
			else
				rm -rf /etc/rc2.d/S01vlvm.sh
				rm -rf /etc/rc3.d/S01vlvm.sh
				rm -rf /etc/rc4.d/S01vlvm.sh
				rm -rf /etc/rc5.d/S01vlvm.sh
				rm -rf /etc/init.d/vlvm.sh
			fi
			if [ "$arch" = "" ]; then
				rm -rf /usr/lib/libBackendWaiter.so
			else
				if [ -d /usr/lib64 ]; then
					rm -rf /usr/lib64/libBackendWaiter.so
				else
					rm -rf /usr/lib/libBackendWaiter.so
				fi
			fi
			rm -rf $inst_path
			rm -rf /etc/visual_lvm
			rm -rf /sbin/vlvmstart
		fi
		;;
	install)
		if [ -f /etc/visual_lvm/install.ini ]; then
			read -n 1 -p "You have installed another Visual LVM already, remove it ? [Y/n]" cmd
			echo ""
			if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
				.$this remove
			else
				echo "stop install"
				exit -1
			fi
		fi
		
		read -p "please specify install path : [/usr/visual_lvm] " param
		if [ "$param" = "" ]; then
			param="/usr/visual_lvm"
		fi
		if [ ! -d $param ]; then
			read -n 1 -p "path $param is not existed, create ? [Y/n]" cmd
			if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
				echo "create target path"
				mkdir -p $param
			else
				echo "stop install"
				exit -1
			fi
		fi
		
		cd $param
		mkdir -p log
		mkdir -p backup
		param=`pwd`
		cd $instpath
		cp ./ $param/ -rf

		port=""
		while [ "$port" = "" ]
		do
			read -p "Specify work port : [80]" port
			if [ "$port" = "" ]; then
				port=80
			fi
			port=`grep '^[[:digit:]]*$' <<< $port`
		done

		echo port $port

		read -s -p "Please set login password : [admin] " pass
		if [ "$pass" = "" ];then
			pass="admin"
		fi
		echo ""

		read -n 1 -p "run automatically Visual LVM after boot ? [Y/n]" cmd
		if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
			if [[ $EUID -ne 0 ]]; then
				echo "Error: this setting must be run as root!" 1>&2
				exit -2
			fi
		fi
		
		cd $param
		./vlvmconsole -chgpass $pass >/dev/nul
		./vlvmconsole -chgport $port >/dev/nul
		
		if [ "$arch" = "" ]; then
			ln -s $param/libBackendWaiter.so /usr/lib/libBackendWaiter.so
		else
			if [ -d /usr/lib64 ]; then
				ln -s $param/libBackendWaiter.so /usr/lib64/libBackendWaiter.so
			else
				ln -s $param/libBackendWaiter.so /usr/lib/libBackendWaiter.so
			fi
		fi

		echo "#!/bin/bash">vlvmstart
		echo "if [[ $EUID -ne 0 ]]; then">>vlvmstart
		echo "	echo 'Error: please run this command with root privilege!' 1>&2">>vlvmstart
		echo "	exit -2">>vlvmstart
		echo "fi">>vlvmstart
		echo 'case "$1" in'>>vlvmstart
		echo "	start)">>vlvmstart
		echo '		run=`ps -ef|grep vlvmserver|sed "/grep/d"`'>>vlvmstart
		echo '		if [ "$run" != "" ]; then'>>vlvmstart
		echo "			echo Visual LVM is running">>vlvmstart
		echo "			exit">>vlvmstart
		echo "		fi">>vlvmstart
		echo "		if [ -f $param/update.sh ]; then">>vlvmstart
		echo "			$param/update.sh">>vlvmstart
		echo "		fi">>vlvmstart
		echo '		curpath=`pwd`'>>vlvmstart
		echo "		cd $param">>vlvmstart
		echo "		./vlvmserver & >/dev/null">>vlvmstart
		echo '		cd $curpath'>>vlvmstart
		echo "">>vlvmstart
		echo "		;;">>vlvmstart
		echo "	restart)">>vlvmstart
		echo '		$0 stop'>>vlvmstart
		echo '		$0 start'>>vlvmstart
		echo "		;;">>vlvmstart
		echo "	stop)">>vlvmstart
		echo '		process=`ps -ef|grep vlvmserver|sed "/grep/d"|awk {'"'"'print $2'"'"'}`'>>vlvmstart
		echo '		if [ "$process" != "" ]; then'>>vlvmstart
		echo '			kill $process &> /dev/nul'>>vlvmstart
		echo "		fi">>vlvmstart
		echo "		;;">>vlvmstart
		echo "">>vlvmstart
		echo "	*)">>vlvmstart
		echo '		echo "Unknown command."'>>vlvmstart
		echo '		echo "Please try vlvmstart {start|restart|stop}"'>>vlvmstart
		echo "		;;">>vlvmstart
		echo "esac">>vlvmstart
		chmod +x vlvmstart
		ln -s $param/vlvmstart /sbin/vlvmstart

		if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
			if [ "$systemctl" == "" ]; then
                                echo "[Unit]" > /usr/lib/systemd/system/visual-lvm.service
                                echo 'Description="Visual LVM service"' >> /usr/lib/systemd/system/visual-lvm.service
                                echo "" >> /usr/lib/systemd/system/visual-lvm.service
                                echo "[Service]" >> /usr/lib/systemd/system/visual-lvm.service
                                echo "Type=forking" >> /usr/lib/systemd/system/visual-lvm.service
                                echo "ExecStart=$param/vlvmstart start" >> /usr/lib/systemd/system/visual-lvm.service
                                echo "ExecReload=$param/vlvmstart restart" >> /usr/lib/systemd/system/visual-lvm.service
                                echo "ExecStop=$param/vlvmstart stop" >> /usr/lib/systemd/system/visual-lvm.service
                                echo "After=network.target" >> /usr/lib/systemd/system/visual-lvm.service
                                echo "" >> /usr/lib/systemd/system/visual-lvm.service
                                echo "[Install]" >> /usr/lib/systemd/system/visual-lvm.service
                                echo "WantedBy=multi-user.target" >> /usr/lib/systemd/system/visual-lvm.service
				systemctl enable visual-lvm.service
				systemctl start visual-lvm
			else
				echo "#!/bin/sh">/etc/init.d/vlvm.sh
				echo "### BEGIN INIT INFO">>/etc/init.d/vlvm.sh
				echo "# Provides:          vlvm.sh">>/etc/init.d/vlvm.sh
				echo "# Required-Start:">>/etc/init.d/vlvm.sh
				echo "# Required-Stop:">>/etc/init.d/vlvm.sh
				echo "# Should-Start:">>/etc/init.d/vlvm.sh
				echo "# Default-Start:     2 3 4 5">>/etc/init.d/vlvm.sh
				echo "# Default-Stop:">>/etc/init.d/vlvm.sh
				echo "# X-Interactive:     true">>/etc/init.d/vlvm.sh
				echo "# Short-Description: Start Visual LVM back-end">>/etc/init.d/vlvm.sh
				echo "### END INIT INFO">>/etc/init.d/vlvm.sh
				echo "">>/etc/init.d/vlvm.sh
				echo '    case "$1" in'>>/etc/init.d/vlvm.sh
				echo "        stop|status)">>/etc/init.d/vlvm.sh
				echo "        #">>/etc/init.d/vlvm.sh
				echo "        ;;">>/etc/init.d/vlvm.sh
				echo "    start|force-reload|restart|reload)">>/etc/init.d/vlvm.sh
				echo "        if [ -f $param/vlvmstart ]; then">>/etc/init.d/vlvm.sh
				echo "            . $param/vlvmstart 1>&2">>/etc/init.d/vlvm.sh
				echo "        fi">>/etc/init.d/vlvm.sh
				echo "        ;;">>/etc/init.d/vlvm.sh
				echo "    *)">>/etc/init.d/vlvm.sh
				echo "	echo 'Usage: /etc/init.d/vlvm.sh {start|reload|restart|force-reload|stop|status}'">>/etc/init.d/vlvm.sh
				echo "        exit 3">>/etc/init.d/vlvm.sh
				echo "        ;;">>/etc/init.d/vlvm.sh
				echo "    esac">>/etc/init.d/vlvm.sh
				chmod +x /etc/init.d/vlvm.sh
				ln -s /etc/init.d/vlvm.sh /etc/rc2.d/S01vlvm.sh
				ln -s /etc/init.d/vlvm.sh /etc/rc3.d/S01vlvm.sh
				ln -s /etc/init.d/vlvm.sh /etc/rc4.d/S01vlvm.sh
				ln -s /etc/init.d/vlvm.sh /etc/rc5.d/S01vlvm.sh
				./vlvmstart start &
			fi
			boot_run="true"
		else
			boot_run="false"
		fi

		echo "Visual LVM installed successfully"
		echo "Please enable port $port and run 'sudo vlvmstart start' to run Visual LVM"
		echo "      -- weLees Visual LVM group"
		echo ""

		if [ ! -d /etc/visual_lvm ]; then
			mkdir -p /etc/visual_lvm
		fi
		
		echo "install_path=$param" > ./$$;echo "init_port=$port" >> ./$$;echo "boot_run=$boot_run" >> ./$$;mv ./$$ /etc/visual_lvm/install.ini
		cd $curpath
		
		;;
	*)
		echo "unknown command"
		echo "please try visual-lvm-install.sh {install|remove}"
		;;
esac
exit

