#!/bin/bash

generateRunningScript()
{
	files="visual-lvm-remote.start visual-lvm-remote.restart visual-lvm-remote.stop visual-lvm-remote.ip-accept visual-lvm-remote.ip-refuse visual-lvm-remote.change-password visual-lvm-remote.change-port vlvmstart"
	for f in $files; do
		file=$$
		echo "#!/bin/bash" >$file
		echo "inst_path='$1'">>$file
		echo "major='$2'">>$file
		echo "minor='$3'">>$file
		sed -i "/#!\/bin\/bash/d" $1/$f
		cat $1/$f >> $file
		rm $1/$f -rf
		mv $file $1/$f
		chmod +x $1/$f
		rm -rf /sbin/$f
		ln -s $1/$f /sbin/$f
	done
}

generateSystemCtlScript()
{
	echo "[Unit]" > $2
	echo 'Description="Visual LVM service"' >> $2
	echo "" >> $2
	echo "[Service]" >> $2
	echo "Type=forking" >> $2
	echo "ExecStart=$1/visual-lvm-remote.start service" >> $2
	echo "ExecReload=$1/visual-lvm-remote.restart service" >> $2
	echo "ExecStop=$1/visual-lvm-remote.stop" >> $2
	echo "After=network.target" >> $2
	echo "" >> $2
	echo "[Install]" >> $2
	echo "WantedBy=multi-user.target" >> $2
}

generateStartupScript()
{
	echo "#!/bin/sh">$1
	echo "### BEGIN INIT INFO">>$1
	echo "# Provides:          vlvm.sh">>$1
	echo "# Required-Start:">>$1
	echo "# Required-Stop:">>$1
	echo "# Should-Start:">>$1
	echo "# Default-Start:     2 3 4 5">>$1
	echo "# Default-Stop:">>$1
	echo "# X-Interactive:     true">>$1
	echo "# Short-Description: Start Visual LVM back-end">>$1
	echo "### END INIT INFO">>$1
	echo "">>$1
	echo '    case "$1" in'>>$1
	echo "        stop|status)">>$1
	echo "        #">>$1
	echo "        ;;">>$1
	echo "    start">>$1
	echo "        if [ -f $param/visual-lvm-remote.start ]; then">>$1
	echo "            . $param/visual-lvm-remote.start 1>&2">>$1
	echo "        fi">>$1
	echo "        ;;">>$1
	echo "    force-reload|restart|reload)">>$1
	echo "        if [ -f $param/visual-lvm-remote.start ]; then">>$1
	echo "            . $param/visual-lvm-remote.restart 1>&2">>$1
	echo "        fi">>$1
	echo "        ;;">>$1
	echo "    *)">>$1
	echo "	echo 'Usage: $1 {start|reload|restart|force-reload|stop|status}'">>$1
	echo "        exit 3">>$1
	echo "        ;;">>$1
	echo "    esac">>$1
}

version="5.6.1363"
edition="Remote"
arch=`uname -i|grep x86_64`

if [[ $EUID -ne 0 ]]; then
	echo "Error: please run this command with root privilege!" 1>&2
	exit -2
fi

verstr="V Mod 6 Step 1363"
curpath=`pwd`
binpath=`dirname $0`
cd $binpath
this=`echo $0|sed "s/$binpath//"`
instpath=`pwd`
systemctl=`systemctl --version`|grep 'No command'	
case "$1" in
	upgrade)
		run=`ps -ef|grep vlvmserver|sed "/grep/d"`
		if [ ! -f /etc/visual_lvm/install.ini ]; then
			echo "Cannot found Visual LVM install information"
			exit -2;
		fi
		if [ "$run" != "" ]; then
			visual-lvm-remote.stop
			echo Stop Visual LVM service for upgrading
		fi
		inst_path=`cat /etc/visual_lvm/install.ini|grep install_path|sed 's/install_path=//'`
		echo Upgrade to Visual LVM $edition $verstr
		mv $inst_path/config.ini $inst_path/config.ini.$$;cp ./ $inst_path/ -rf;rm $inst_path/config.ini;mv $inst_path/config.ini.$$ $inst_path/config.ini
		cd $inst_path
		generateRunningScript $inst_path V 6
		cd $curpath
		if [ ! -d /usr/share/applications ]; then
			mkdir -p /usr/share/applications
		fi
		cp $inst_path/*.desktop /usr/share/applications/ -rf
		sed -i "s@\$INSTALL_PATH@$inst_path@" /usr/share/applications/visual-lvm-remote.desktop
		
		if [ "$run" != "" ]; then
			echo Restart Visual LVM service
			visual-lvm-remote.start
		fi
		echo Done
		;;
	remove)
		visual-lvm-remote.stop
		if [ -f /etc/visual_lvm/install.ini ]; then
			inst_path=`cat /etc/visual_lvm/install.ini|grep install_path|sed 's/install_path=//'`
			if [ "$systemctl" == "" ]; then
				systemctl stop visual-lvm.service &>/dev/null
				systemctl disable visual-lvm.service &>/dev/null
			else
				rm -rf /etc/rc2.d/S01vlvm.sh
				rm -rf /etc/rc3.d/S01vlvm.sh
				rm -rf /etc/rc4.d/S01vlvm.sh
				rm -rf /etc/rc5.d/S01vlvm.sh
				rm -rf /etc/init.d/vlvm.sh
			fi
			[ -f /usr/lib/ld-linux.so.3 ] && [ "`ls -l /usr/lib/ld-linux.so.3|awk '{print $NF}'`" == "$inst_path/ld-linux.so.3" ] && rm /usr/lib/ld-linux.so.3
			[ -f /usr/lib/ld-linux.aarch64.so.1 ] && [ "`ls -l /usr/lib/ld-linux.aarch64.so.1|awk '{print $NF}'`" == "$inst_path/ld-linux.aarch64.so.1" ] && rm /usr/lib/ld-linux.aarch64.so.1
			rm -rf $inst_path
			rm -rf /etc/visual_lvm
			rm -rf /sbin/vlvmstart
			rm -rf /sbin/visual-lvm-remote.start
			rm -rf /sbin/visual-lvm-remote.restart
			rm -rf /sbin/visual-lvm-remote.stop
			rm -rf /sbin/visual-lvm-remote.ip-accept
			rm -rf /sbin/visual-lvm-remote.ip-refuse
			rm -rf /sbin/visual-lvm-remote.change-password
			rm -rf /sbin/visual-lvm-remote.change-port
			rm -rf /usr/share/applications/visual-lvm-remote.desktop
			echo Visual LVM removed
		fi
		;;
	install)
		echo Install Visual LVM $edition $verstr ...
		if [ -f /etc/visual_lvm/install.ini ]; then
			read -n 1 -p "You have installed another Visual LVM already, remove it ? [y/N]" cmd
			echo ""
			if [ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
				.$this remove
			else
				echo ""
				read -n 1 -p "Do you want to upgrade to Visual LVM $edition $verstr ? [y/N]" cmd
				echo ""
				if [ "$cmd" = "" ]||[ "$cmd" = "n" ]||[ "$cmd" = "N" ]; then
					exit 0;
				else
					$0 upgrade
					exit $errorlevel
				fi
			fi
		fi
		
		path_query=1
		default_path="/usr/visual_lvm"
		while [ "$path_query" = "1" ]; do
			read -p "Please specify install path : [$default_path] " param
			if [ "$param" = "" ]; then
				echo " "
				param=$default_path
			fi
			if [ "$param" = "/" ]; then
				echo "You cannot install Visual LVM to root path!"
			else
				path_query=0
			fi
		done
		if [ ! -d $param ]; then
			read -n 1 -p "Path $param is not existed, create ? [Y/n]" cmd
			if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
				echo " "
				echo "Target path created"
				mkdir -p $param
			else
				echo " "
				echo "Stop install"
				exit -1
			fi
		fi
		
		cd $param
		mkdir -p log
		mkdir -p backup
		param=`pwd`
		cd $instpath
		cp ./ $param/ -rf
		[ -f $param/ld-linux.so.3 ] && [ ! -f /usr/lib/ld-linux.so.3 ] && [ ! -f /lib/ld-linux.so.3 ] && ln -s $param/ld-linux.so.3 /usr/lib/ld-linux.so.3
		[ -f $param/ld-linux.aarch64.so.1 ] && [ ! -f /usr/lib/ld-linux.aarch64.so.1 ] && [ ! -f /lib/ld-linux.aarch64.so.1 ] && ln -s $param/ld-linux.aarch64.so.1 /usr/lib/ld-linux.aarch64.so.1
		[[ ! "`echo $LD_PRELOAD`" =~ "$param/preloadable_libiconv.so" ]] && export LD_PRELOAD=$LD_PRELOAD:$param/preloadable_libiconv.so
		if [ ! -d /usr/share/applications ]; then
			mkdir -p /usr/share/applications
		fi
		cp $param/*.desktop /usr/share/applications/ -rf
		sed -i "s@\$INSTALL_PATH@$param@" /usr/share/applications/visual-lvm-remote.desktop
		
		port=""
		while [ "$port" = "" ]
		do
			read -p "Specify work port : [8341]" port
			if [ "$port" = "" ]; then
				port=8341
			fi
			port=`grep '^[[:digit:]]*$' <<< $port`
		done
		
		echo Using port $port
		cd $param
		
		echo "The default username is admin for login"
		read -n 1 -p "Do you want to change login password(default is admin) ? [Y/n]" cmd
		if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
			if [ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
				echo ""
			fi
			./vlvmconsole -chgpass
		fi
		
		echo " "
		read -n 1 -p "Running automatically Visual LVM after boot ? [Y/n]" cmd
		if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
			if [[ $EUID -ne 0 ]]; then
				echo "Error: this setting must be run as root!" 1>&2
				exit -2
			fi
		fi
		echo " "
		
		./vlvmconsole -chgport port=$port >/dev/null
		
		generateRunningScript $param V 6
		
		if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
			if [ "$systemctl" == "" ]; then
				file='/etc/systemd/system/visual-lvm.service'
				generateSystemCtlScript $param $file
				systemctl enable visual-lvm.service
				systemctl start visual-lvm
			else
				file='/etc/init.d/vlvm.sh'
				generateStartupScript $file
				chmod +x $file
				ln -s $file /etc/rc2.d/S01vlvm.sh
				ln -s $file /etc/rc3.d/S01vlvm.sh
				ln -s $file /etc/rc4.d/S01vlvm.sh
				ln -s $file /etc/rc5.d/S01vlvm.sh
				./visual-lvm-remote.start &
			fi
			boot_run="true"
		else
			boot_run="false"
		fi
		
		echo "Visual LVM installed successfully"
		echo "Please enable port $port and run 'sudo visual-lvm-remote.start' to run Visual LVM"
		echo ""
		echo "The support page : https://www.welees.com/lvm-support.html"
		echo ""
		echo "The user guide page : https://www.welees.com/visual-lvm-user-guide.html"
		echo ""
		echo "Wish Visual LVM helps you work more easily & more efficiently"
		echo "      -- weLees Visual LVM group"
		echo ""
		
		if [ ! -d /etc/visual_lvm ]; then
			mkdir -p /etc/visual_lvm
		fi
		
		echo "install_path=$param" > ./$$;echo "init_port=$port" >> ./$$;echo "boot_run=$boot_run" >> ./$$;echo "edition=$edition" >> ./$$;echo "version=$version" >> ./$$;mv ./$$ /etc/visual_lvm/install.ini
		cd $curpath
		
		;;
	*)
		echo "unknown command"
		echo "please try visual-lvm-install.sh {install|remove|upgrade}"
		;;
esac
exit

