#!/bin/bash

generateSystemCtlScript()
{
	echo "[Unit]" > $3
	echo 'Description="Visual LVM service"' >> $3
	echo "" >> $3
	echo "[Service]" >> $3
	echo "Type=forking" >> $3
	echo "ExecStart=$1/$2 start" >> $3
	echo "ExecReload=$1/$2 restart" >> $3
	echo "ExecStop=$1/$2 stop" >> $3
	echo "After=network.target" >> $3
	echo "" >> $3
	echo "[Install]" >> $3
	echo "WantedBy=multi-user.target" >> $3
}

generateStartupScript()
{
	echo "#!/bin/sh">$1
	echo "### BEGIN INIT INFO">>$1
	echo "# Provides:          vlvm.sh">>$1
	echo "# Required-Start:">>$1
	echo "# Required-Stop:">>$1
	echo "# Should-Start:">>$1
	echo "# Default-Start:     2 3 4 5">>$1
	echo "# Default-Stop:">>$1
	echo "# X-Interactive:     true">>$1
	echo "# Short-Description: Start Visual LVM back-end">>$1
	echo "### END INIT INFO">>$1
	echo "">>$1
	echo '    case "$1" in'>>$1
	echo "        stop|status)">>$1
	echo "        #">>$1
	echo "        ;;">>$1
	echo "    start|force-reload|restart|reload)">>$1
	echo "        if [ -f $param/vlvmstart ]; then">>$1
	echo "            . $param/vlvmstart 1>&2">>$1
	echo "        fi">>$1
	echo "        ;;">>$1
	echo "    *)">>$1
	echo "	echo 'Usage: $1 {start|reload|restart|force-reload|stop|status}'">>$1
	echo "        exit 3">>$1
	echo "        ;;">>$1
	echo "    esac">>$1
}

generateRunningScript()
{
	echo "#!/bin/bash">$2
	echo "if [[ $EUID -ne 0 ]]; then">>$2
	echo "	echo 'Error: please run this command with root privilege!' 1>&2">>$2
	echo "	exit -2">>$2
	echo "fi">>$2
	echo 'case "$1" in'>>$2
	echo "	start)">>$2
	echo "		export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$1">>$2
	echo '		run=`ps -ef|grep vlvmserver|sed "/grep/d"`'>>$2
	echo '		if [ "$run" != "" ]; then'>>$2
	echo "			echo Visual LVM is running">>$2
	echo "			exit">>$2
	echo "		fi">>$2
	echo "		if [ -f $1/update.sh ]; then">>$2
	echo "			$1/update.sh">>$2
	echo "		fi">>$2
	echo '		curpath=`pwd`'>>$2
	echo "		cd $1">>$2
	echo "		./vlvmserver & >/dev/null">>$2
	echo '		cd $curpath'>>$2
	echo "">>$2
	echo "		;;">>$2
	echo "	restart)">>$2
	echo '		$0 stop'>>$2
	echo '		$0 start'>>$2
	echo "		;;">>$2
	echo "	stop)">>$2
	echo '		process=`ps -ef|grep vlvmserver|sed "/grep/d"|awk {'"'"'print $2'"'"'}`'>>$2
	echo '		if [ "$process" != "" ]; then'>>$2
	echo '			kill $process &> /dev/nul'>>$2
	echo "			echo 'Visual LVM has been stopped'" >>$2
	echo "		else" >>$2
	echo "			echo 'Visual LVM is not running'" >>$2
	echo "		fi">>$2
	echo "		;;">>$2
	echo "">>$2
	echo "	*)">>$2
	echo '		echo "Unknown command."'>>$2
	echo '		echo "Please try $2 {start|restart|stop}"'>>$2
	echo "		;;">>$2
	echo "esac">>$2
	chmod +x $2
}

version="4.3.750"
edition="Remote"
arch=`uname -i|grep x86_64`

if [[ $EUID -ne 0 ]]; then
	echo "Error: please run this command with root privilege!" 1>&2
	exit -2
fi

verstr="IV Mod 3 Step 750"
curpath=`pwd`
binpath=`dirname $0`
cd $binpath
this=`echo $0|sed "s/$binpath//"`
instpath=`pwd`
systemctl=`systemctl --version`|grep 'No command'	
case "$1" in
	upgrade)
		run=`ps -ef|grep vlvmserver|sed "/grep/d"`
		if [ ! -f /etc/visual_lvm/install.ini ]; then
			echo "Cannot found Visual LVM install information"
			exit -2;
		fi
		if [ "$run" != "" ]; then
			vlvmstart stop
			echo Stop Visual LVM service for upgrading
		fi
		inst_path=`cat /etc/visual_lvm/install.ini|grep install_path|sed 's/install_path=//'`
		echo Upgrade to Visual LVM $edition $verstr
		mv $inst_path/config.ini $inst_path/config.ini.$$;cp ./ $inst_path/ -rf;rm $inst_path/config.ini;mv $inst_path/config.ini.$$ $inst_path/config.ini
		
		if [ "$run" != "" ]; then
			echo Restart Visual LVM service
			vlvmstart start
		fi
		echo Done
		;;
	remove)
		vlvmstart stop
		if [ -f /etc/visual_lvm/install.ini ]; then
			inst_path=`cat /etc/visual_lvm/install.ini|grep install_path|sed 's/install_path=//'`
			if [ "$systemctl" == "" ]; then
				vlvmstart stop
				systemctl stop visual-lvm.service
				systemctl disable visual-lvm.service
			else
				rm -rf /etc/rc2.d/S01vlvm.sh
				rm -rf /etc/rc3.d/S01vlvm.sh
				rm -rf /etc/rc4.d/S01vlvm.sh
				rm -rf /etc/rc5.d/S01vlvm.sh
				rm -rf /etc/init.d/vlvm.sh
			fi
			rm -rf $inst_path
			rm -rf /etc/visual_lvm
			rm -rf /sbin/vlvmstart
			echo Visual LVM removed
		fi
		;;
	install)
		echo Install Visual LVM $edition $verstr ...
		if [ -f /etc/visual_lvm/install.ini ]; then
			read -n 1 -p "You have installed another Visual LVM already, remove it ? [Y/n]" cmd
			echo ""
			if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
				.$this remove
			else
				echo ""
				read -n 1 -p "Do you want to upgrade to Visual LVM $edition $verstr ? [y/N]" cmd
				echo ""
				if [ "$cmd" = "" ]||[ "$cmd" = "n" ]||[ "$cmd" = "N" ]; then
					exit 0;
				else
					$0 upgrade
					exit $errorlevel
				fi
			fi
		fi
		
		read -p "please specify install path : [/usr/visual_lvm] " param
		if [ "$param" = "" ]; then
			param="/usr/visual_lvm"
		fi
		if [ ! -d $param ]; then
			read -n 1 -p "path $param is not existed, create ? [Y/n]" cmd
			if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
				echo "create target path"
				mkdir -p $param
			else
				echo "stop install"
				exit -1
			fi
		fi
		
		cd $param
		mkdir -p log
		mkdir -p backup
		param=`pwd`
		cd $instpath
		cp ./ $param/ -rf

		port=""
		while [ "$port" = "" ]
		do
			read -p "Specify work port : [80]" port
			if [ "$port" = "" ]; then
				port=80
			fi
			port=`grep '^[[:digit:]]*$' <<< $port`
		done

		echo port $port

		read -s -p "Please set login password : [admin] " pass
		if [ "$pass" = "" ];then
			pass="admin"
		fi
		echo ""

		read -n 1 -p "run automatically Visual LVM after boot ? [Y/n]" cmd
		if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
			if [[ $EUID -ne 0 ]]; then
				echo "Error: this setting must be run as root!" 1>&2
				exit -2
			fi
		fi
		
		cd $param
		./vlvmconsole -chgpass $pass >/dev/nul
		./vlvmconsole -chgport $port >/dev/nul
		
		generateRunningScript $param vlvmstart
		ln -s $param/vlvmstart /sbin/vlvmstart

		if [ "$cmd" = "" ]||[ "$cmd" = "y" ]||[ "$cmd" = "Y" ]; then
			if [ "$systemctl" == "" ]; then
				file='/etc/systemd/system/visual-lvm.service'
				generateSystemCtlScript $param vlvmstart $file
				systemctl enable visual-lvm.service
				systemctl start visual-lvm
			else
				file='/etc/init.d/vlvm.sh'
				generateStartupScript $file
				chmod +x $file
				ln -s $file /etc/rc2.d/S01vlvm.sh
				ln -s $file /etc/rc3.d/S01vlvm.sh
				ln -s $file /etc/rc4.d/S01vlvm.sh
				ln -s $file /etc/rc5.d/S01vlvm.sh
				./vlvmstart start &
			fi
			boot_run="true"
		else
			boot_run="false"
		fi

		echo "Visual LVM installed successfully"
		echo "Please enable port $port and run 'sudo vlvmstart start' to run Visual LVM"
		echo ""
		echo "The support page : https://www.welees.com/lvm-support.html"
		echo ""
		echo "The user guide page : https://www.welees.com/visual-lvm-user-guide.html"
		echo ""
		echo "Wish Visual LVM helps you work more easily & more efficiently"
		echo "      -- weLees Visual LVM group"
		echo ""

		if [ ! -d /etc/visual_lvm ]; then
			mkdir -p /etc/visual_lvm
		fi
		
		echo "install_path=$param" > ./$$;echo "init_port=$port" >> ./$$;echo "boot_run=$boot_run" >> ./$$;echo "edition=$edition" >> ./$$;echo "version=$version" >> ./$$;mv ./$$ /etc/visual_lvm/install.ini
		cd $curpath
		
		;;
	*)
		echo "unknown command"
		echo "please try visual-lvm-install.sh {install|remove|upgrade}"
		;;
esac
exit

